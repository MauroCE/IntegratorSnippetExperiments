This folder contains scripts that illustrate the properties of the particle smoothing
algorithms discussed or proposed in Dau & Chopin (2022).


Reference
---------
Dau, H.D. & Chopin, N. (2022). On backward smoothing algorithms, arxiv 2207.00976, 
<https://arxiv.org/abs/2207.00976>.
