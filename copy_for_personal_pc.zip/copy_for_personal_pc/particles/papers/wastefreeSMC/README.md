This folder contains scripts that reproduce some of the numerical experiments
of Dau & Chopin (2020).

Reference
---------

Dau, H.D. and Chopin, N. (2022). Waste-free sequential Monte Carlo,
Journal of the Royal Statistical Society Series B: Statistical Methodology 84.1
(2022): 114-148.
